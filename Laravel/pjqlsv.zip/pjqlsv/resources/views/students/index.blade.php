@extends('students.master')
@section('content')
@if($message = Session::get('success'))
<div class="alert alert-success">
{{$message}}
</div>
@endif
<div class="container mt-5">
<h1 class="text-primary mt-3 mb-4 text-center"><b>Quan ly sinh vien</b></h1>
</div>
<div class="card">
    <div class="card-header">
      <div class="row">
        <div class="col col-md-6"><b></b></div>
        <div class="col col-md-6">
        <a href="{{ route('students.create') }}" class="btn btn-success btn-sm float-end">Create Student</a>

        </div>
      </div>  
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Ma sinh vien</th>
                <th>Ten sinh vien</th>
                <th>Gioi tinh</th>
                <th>Dia chi Email</th>
                <!-- <th>ClassID</th> -->
                <th>Lop</th>
                <th>Thao tac</th>
            </tr>
            @if(count($students)>0)
                @foreach($students as $row)
                    <tr>
                        <td>{{$row->StudentID}}</td>
                        <td>{{$row->StudentName}}</td>
                        <td>@if($row->StudentGender==0) Nam @else Nu @endif</td>
                        <td>{{$row->StudentEmail}}</td>
                        <td>{{$row->ClassRoom->ClassRoomName}}</td>
                        <td>
                            <form action="{{route('students.destroy', $row->StudentID)}}" method="post">
                                @csrf
                                @method('DELETE')
                                <a href="{{route('students.show', $row->StudentID)}}" class="btn btn-primary">Xem</a>
                                <a href="{{route('students.edit', $row->StudentID)}}" class="btn btn-warning">Sua</a>
                                <input type="submit" value="Xoa" class="btn btn-danger btn-sm">
                            </form>
                        </td>
                    </tr>
                    @endforeach
                <tr><td colspan="5" class="text-center">No data found</td>
                
                </tr>
                @endif
        </table>
        {!! $students->onEachSide(0)->links() !!}
    </div>
</div>
@endsection