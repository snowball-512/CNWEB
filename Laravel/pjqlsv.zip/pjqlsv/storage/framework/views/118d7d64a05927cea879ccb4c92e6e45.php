<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<?php echo e($message); ?>

</div>
<?php endif; ?>
<div class="container mt-5">
<h1 class="text-primary mt-3 mb-4 text-center"><b>Quan ly sinh vien</b></h1>
</div>
<div class="card">
    <div class="card-header">
      <div class="row">
        <div class="col col-md-6"><b></b></div>
        <div class="col col-md-6">
        <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success btn-sm float-end">Create Student</a>

        </div>
      </div>  
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Ma sinh vien</th>
                <th>Ten sinh vien</th>
                <th>Gioi tinh</th>
                <th>Dia chi Email</th>
                <!-- <th>ClassID</th> -->
                <th>Lop</th>
                <th>Thao tac</th>
            </tr>
            <?php if(count($students)>0): ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->StudentID); ?></td>
                        <td><?php echo e($row->StudentName); ?></td>
                        <td><?php if($row->StudentGender==0): ?> Nam <?php else: ?> Nu <?php endif; ?></td>
                        <td><?php echo e($row->StudentEmail); ?></td>
                        <td><?php echo e($row->ClassRoom->ClassRoomName); ?></td>
                        <td>
                            <form action="<?php echo e(route('students.destroy', $row->StudentID)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a href="<?php echo e(route('students.show', $row->StudentID)); ?>" class="btn btn-primary">Xem</a>
                                <a href="<?php echo e(route('students.edit', $row->StudentID)); ?>" class="btn btn-warning">Sua</a>
                                <input type="submit" value="Xoa" class="btn btn-danger btn-sm">
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr><td colspan="5" class="text-center">No data found</td>
                
                </tr>
                <?php endif; ?>
        </table>
        <?php echo $students->onEachSide(0)->links(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\pjqlsv\resources\views/students/index.blade.php ENDPATH**/ ?>